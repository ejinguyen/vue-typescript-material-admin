import ContactForm from '@/components/form/ContactForm.vue'
import PaymentForm from '@/components/form/PaymentForm.vue'
export default {
  components: {
    ContactForm,
    PaymentForm
  },
  data() {
    return {}
  },
  computed: {},
  methods: {}
}
