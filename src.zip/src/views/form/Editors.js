import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import { quillEditor } from 'vue-quill-editor'
export default {
  components: {
    quillEditor,
  },
  data() {
    return {
      content: 'Compose Epic Story...',
      editorOption: {},
    }
  },
  computed: {},

  methods: {},
}