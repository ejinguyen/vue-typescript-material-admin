import MailMenu from '@/components/email/MailMenu.vue'
export default {
  components: {
    MailMenu
  },
  data() {
    return {}
  },
  computed: {},
  methods: {
    handleCompose() {}
  },

  created() {}
}
