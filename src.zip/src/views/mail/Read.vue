<template>
  <div></div>
</template>
<script lang="js" src="./Read.js"></script>
