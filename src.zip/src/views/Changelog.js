export default {
    data() {
      return {
        changelogs: [
          {
            version: '0.1.4',
            tag: 'patch',
            color: 'primary',
            logs: [
              '* add event color in event form (b87165a)',
              '* update calendar (a7e2f9f)',
              '* add event in calendar (f1d67b9)',
              '* update work flow (79d77b9)',
              '* docs: update readme (a30b6bd)'
            ]
          }
        ]
      }
    }
  }