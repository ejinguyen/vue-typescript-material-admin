import UserForm from '@/components/form/UserForm.vue'
export default {
  components: {
    UserForm
  },
  props: {
    id: [Number, String]
  }
}