
export default {
    methods: {
        goHome() {
            this.$router.push({ path: '/' })
        },
    },
}
