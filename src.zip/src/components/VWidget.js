export default {
    name: 'VWidget',
    props: {
      title: {
        type: String
      },
      enableHeader: {
        type: Boolean,
        default: true
      },
      contentBg: {
        type: String,
        default: 'white'
      }
    },
  
    data() {
      return {}
    },
    computed: {}
  }