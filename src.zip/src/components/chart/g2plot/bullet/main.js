import Bullet from './main'

Bullet.install = function(Vue) {
  Vue.component(Bullet.name, Bullet)
}

export default Bullet
