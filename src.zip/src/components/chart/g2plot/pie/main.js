import Pie from './main'

Pie.install = function(Vue) {
  Vue.component(Pie.name, Pie)
}

export default Pie
