import API from '@/api'
import ChatMenu from '@/components/chat/ChatMenu.vue'
export default {
  components: {
    ChatMenu
  },
  data: () => ({
    menus: API.getChatMenu
  }),
  computed: {
    hideBottomNav() {
      return (
        this.$route.params.uuid !== undefined &&
        this.$route.name === 'ChatMessaging'
      )
    }
  },
  methods: {
    handleClick() {
      this.$router.go(-1)
    }
  }
}
