<template>
  <router-view></router-view>
</template>
<script lang="js" src="./RouteWrapper.js"></script>
<style></style>
