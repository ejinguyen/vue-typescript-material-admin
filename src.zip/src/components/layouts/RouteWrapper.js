export default {
  name: 'RouteWrapper'
}