export default {
  data: () => ({}),

  methods: {},
}